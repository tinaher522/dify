DEFAULT_PLUGIN_ID = "langgenius"
